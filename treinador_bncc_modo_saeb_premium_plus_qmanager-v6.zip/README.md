# Treinador BNCC | Modo SAEB (demo)

- Modo SAEB com tempo máximo da prova e retomada com tempo restante
- Login por e-mail/senha + recuperação (token de dev)
- Admin (tempo/quantidade/blueprint por eixo + importação do banco)
- Banco em SQLite

## Rodar
```bash
cd server
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/Mac: source .venv/bin/activate
pip install flask
python app.py
```
Abra: http://127.0.0.1:5000

## Admin padrão
- admin@local / admin123


## Matérias no Modo SAEB
- O professor pode selecionar as matérias (Língua Portuguesa, Artes, Interdisciplinar) antes de iniciar.
- O backend filtra as questões por `subject`.


## Importação por lote
- Admin > Importação por lote: envie 1+ arquivos JSON.
- O importador lê o conteúdo (chaves `questions`, `data`, lista direta ou blocos `questoes`). Não depende do nome do arquivo.


## Premium+: validação forte, relatório e catálogo
- Importação agora valida: 6 alternativas, 1 correta, opções únicas.
- Gera relatório por arquivo (motivo do erro e exemplos).
- Catálogo BNCC: filtra habilidades e cria prova SAEB custom por habilidade.


## Gerenciador de questões (Admin)
- Filtros: matéria, série, dificuldade, eixo, bncc_code e busca por texto.
- Ações: editar, remover e adicionar manualmente.
- Validação forte aplicada também no create/update.
