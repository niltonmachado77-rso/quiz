# Treinador BNCC | Modo SAEB (demo)

- Modo SAEB com tempo máximo da prova e retomada com tempo restante
- Login por e-mail/senha + recuperação (token de dev)
- Admin (tempo/quantidade/blueprint por eixo + importação do banco)
- Banco em SQLite

## Rodar
```bash
cd server
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/Mac: source .venv/bin/activate
pip install flask
python app.py
```
Abra: http://127.0.0.1:5000

## Admin padrão
- admin@local / admin123


## Matérias no Modo SAEB
- O professor pode selecionar as matérias (Língua Portuguesa, Artes, Interdisciplinar) antes de iniciar.
- O backend filtra as questões por `subject`.
