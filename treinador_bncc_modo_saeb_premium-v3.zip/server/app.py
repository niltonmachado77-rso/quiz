from __future__ import annotations

import json
import os
import sqlite3
import secrets
from datetime import datetime, timedelta, timezone
from functools import wraps
from typing import Any, Dict, List

from flask import Flask, jsonify, request, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "app.db")
STATIC_DIR = os.path.join(BASE_DIR, "static")

def utc_now() -> datetime:
    return datetime.now(timezone.utc)

def db() -> sqlite3.Connection:
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON;")
    return con

def default_settings() -> Dict[str, Any]:
    # Tudo configurável no painel admin.
    return {
        "mode_default": "normal",  # normal | saeb
        "saeb": {
            "enabled": True,
            "time_limit_minutes": 90,
            "total_questions": 24,
            # Organizar por eixo estruturante:
            "eixos": {
                "leitura": 10,
                "producao": 6,
                "oralidade": 3,
                "analise_linguistica": 3,
                "processos_criacao_artes": 2
            },
            "allow_resume": True,
            "subjects_allowed": ["lingua_portuguesa", "artes", "interdisciplinar"],
            "subjects_default": ["lingua_portuguesa", "artes"],
            "shuffle_questions": True
        }
    }

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  series TEXT,
  role TEXT NOT NULL DEFAULT 'student', -- student | admin
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  token TEXT UNIQUE NOT NULL,
  created_at TEXT NOT NULL,
  last_seen_at TEXT NOT NULL,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value_json TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS questions (
  id TEXT PRIMARY KEY,
  year TEXT NOT NULL,                 -- 5ano..9ano
  subject TEXT NOT NULL,              -- lingua_portuguesa | artes | interdisciplinar
  eixo TEXT NOT NULL,                 -- leitura | producao | oralidade | analise_linguistica | processos_criacao_artes
  bncc_code TEXT,                     -- ex: EF67LP05
  difficulty TEXT NOT NULL,           -- easy | medium | hard
  prompt TEXT NOT NULL,
  options_json TEXT NOT NULL,         -- JSON list[str]
  correct_index INTEGER NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS saeb_attempts (
  id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  created_at TEXT NOT NULL,
  started_at TEXT,
  finished_at TEXT,
  time_limit_seconds INTEGER NOT NULL,
  remaining_seconds INTEGER NOT NULL,
  current_index INTEGER NOT NULL DEFAULT 0,
  subjects_json TEXT NOT NULL DEFAULT '[]', -- JSON list[str]
  questions_json TEXT NOT NULL,       -- JSON list[question_id]
  answers_json TEXT NOT NULL DEFAULT '[]', -- JSON list[{question_id, selected_index, is_correct, answered_at}]
  status TEXT NOT NULL DEFAULT 'active',    -- active | finished | expired
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);


CREATE TABLE IF NOT EXISTS password_resets (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  expires_at TEXT NOT NULL,
  used_at TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
"""

def json_load(s: str):
    return json.loads(s) if s else None

def json_dump(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False)

def init_db() -> None:
    with db() as con:
        con.executescript(SCHEMA_SQL)

        # lightweight migrations
        try:
            con.execute("ALTER TABLE saeb_attempts ADD COLUMN subjects_json TEXT NOT NULL DEFAULT '[]'")
        except Exception:
            pass

        # bootstrap settings if empty
        cur = con.execute("SELECT COUNT(*) AS c FROM settings")
        if cur.fetchone()["c"] == 0:
            con.execute(
                "INSERT INTO settings (key, value_json) VALUES (?, ?)",
                ("system", json_dump(default_settings())),
            )

        # bootstrap admin if missing
        cur = con.execute("SELECT COUNT(*) AS c FROM users WHERE role='admin'")
        if cur.fetchone()["c"] == 0:
            # default admin: admin@local / admin123 (troque no banco depois)
            con.execute(
                "INSERT INTO users (email, name, series, role, password_hash, created_at) VALUES (?,?,?,?,?,?)",
                ("admin@local", "Admin", None, "admin", generate_password_hash("admin123"), utc_now().isoformat()),
            )

def get_settings(con: sqlite3.Connection) -> Dict[str, Any]:
    row = con.execute("SELECT value_json FROM settings WHERE key='system'").fetchone()
    if not row:
        return default_settings()
    try:
        return json.loads(row["value_json"])
    except Exception:
        return default_settings()

def set_settings(con: sqlite3.Connection, value: Dict[str, Any]) -> None:
    con.execute(
        "INSERT INTO settings(key, value_json, updated_at) VALUES('system', ?, datetime('now')) "
        "ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json, updated_at=datetime('now')",
        (json_dump(value),)
    )

def require_auth(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        token = None
        auth = request.headers.get("Authorization", "")
        if auth.startswith("Bearer "):
            token = auth.split(" ", 1)[1].strip()
        if not token:
            return jsonify({"ok": False, "error": "missing_token"}), 401

        with db() as con:
            row = con.execute(
                "SELECT s.user_id, u.email, u.name, u.series, u.role "
                "FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=?",
                (token,)
            ).fetchone()
            if not row:
                return jsonify({"ok": False, "error": "invalid_token"}), 401

            con.execute("UPDATE sessions SET last_seen_at=? WHERE token=?", (utc_now().isoformat(), token))
            request.user = dict(row)  # type: ignore[attr-defined]

        return fn(*args, **kwargs)
    return wrapper

def require_admin(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        user = getattr(request, "user", None)
        if not user or user.get("role") != "admin":
            return jsonify({"ok": False, "error": "admin_required"}), 403
        return fn(*args, **kwargs)
    return wrapper

def new_id(prefix: str) -> str:
    return f"{prefix}_{secrets.token_urlsafe(12)}"

def pick_questions(con: sqlite3.Connection, year: str, blueprint: Dict[str, int], shuffle: bool, subjects: List[str]) -> List[str]:
    picked: List[str] = []
    for eixo, qty in blueprint.items():
        qty = int(qty or 0)
        if qty <= 0:
            continue
        subj = subjects if subjects else []
        if subj:
            q = "SELECT id FROM questions WHERE year=? AND eixo=? AND subject IN (%s) ORDER BY RANDOM() LIMIT ?" % ",".join("?"*len(subj))
            params = [year, eixo, *subj, qty]
        else:
            q = "SELECT id FROM questions WHERE year=? AND eixo=? ORDER BY RANDOM() LIMIT ?"
            params = [year, eixo, qty]
        rows = con.execute(q, params).fetchall()
        picked += [r["id"] for r in rows]

    total_needed = sum(max(0, int(v)) for v in blueprint.values())
    if len(picked) < total_needed:
        need = total_needed - len(picked)
        if subjects:
            q = "SELECT id FROM questions WHERE year=? AND subject IN (%s) ORDER BY RANDOM() LIMIT ?" % ",".join("?"*len(subjects))
            params = [year, *subjects, need]
        else:
            q = "SELECT id FROM questions WHERE year=? ORDER BY RANDOM() LIMIT ?"
            params = [year, need]
        rows = con.execute(q, params).fetchall()
        picked += [r["id"] for r in rows]

    if shuffle and picked:
        rows = con.execute(
            "SELECT id FROM questions WHERE id IN (%s) ORDER BY RANDOM()" % ",".join("?"*len(picked)),
            picked
        ).fetchall()
        if rows:
            picked = [r["id"] for r in rows]
    return picked

def fetch_question(con: sqlite3.Connection, qid: str) -> Dict[str, Any]:
    row = con.execute("SELECT * FROM questions WHERE id=?", (qid,)).fetchone()
    if not row:
        return {"id": qid, "prompt": "Questão não encontrada (import pendente).", "options": [], "eixo": "", "bncc_code": None}
    return {
        "id": row["id"],
        "year": row["year"],
        "subject": row["subject"],
        "eixo": row["eixo"],
        "bncc_code": row["bncc_code"],
        "difficulty": row["difficulty"],
        "prompt": row["prompt"],
        "options": json_load(row["options_json"]),
    }

def _attempt_public(row: sqlite3.Row) -> Dict[str, Any]:
    return {
        "id": row["id"],
        "created_at": row["created_at"],
        "started_at": row["started_at"],
        "finished_at": row["finished_at"],
        "time_limit_seconds": row["time_limit_seconds"],
        "remaining_seconds": row["remaining_seconds"],
        "current_index": row["current_index"],
        "total": len(json_load(row["questions_json"]) or []),
        "answers": json_load(row["answers_json"]) or [],
        "status": row["status"]
    }

app = Flask(__name__, static_folder=STATIC_DIR, static_url_path="/")

@app.get("/")
def index():
    return send_from_directory(STATIC_DIR, "index.html")

@app.get("/api/health")
def health():
    return jsonify({"ok": True, "time": utc_now().isoformat()})

@app.post("/api/auth/register")
def register():
    data = request.get_json(force=True, silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    name = (data.get("name") or "").strip()
    series = (data.get("series") or "").strip() or None
    password = (data.get("password") or "")

    if not email or "@" not in email:
        return jsonify({"ok": False, "error": "invalid_email"}), 400
    if len(name) < 2:
        return jsonify({"ok": False, "error": "invalid_name"}), 400
    if len(password) < 6:
        return jsonify({"ok": False, "error": "weak_password"}), 400

    with db() as con:
        try:
            con.execute(
                "INSERT INTO users(email, name, series, role, password_hash, created_at) VALUES (?,?,?,?,?,?)",
                (email, name, series, "student", generate_password_hash(password), utc_now().isoformat())
            )
        except sqlite3.IntegrityError:
            return jsonify({"ok": False, "error": "email_exists"}), 409

    return jsonify({"ok": True})

@app.post("/api/auth/login")
def login():
    data = request.get_json(force=True, silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    password = (data.get("password") or "")
    if not email or not password:
        return jsonify({"ok": False, "error": "missing_credentials"}), 400

    with db() as con:
        row = con.execute("SELECT id, password_hash, name, series, role FROM users WHERE email=?", (email,)).fetchone()
        if not row or not check_password_hash(row["password_hash"], password):
            return jsonify({"ok": False, "error": "invalid_credentials"}), 401

        sid = new_id("sess")
        token = secrets.token_urlsafe(24)
        now = utc_now().isoformat()
        con.execute("INSERT INTO sessions(id, user_id, token, created_at, last_seen_at) VALUES (?,?,?,?,?)", (sid, row["id"], token, now, now))
        return jsonify({"ok": True, "token": token, "user": {"email": email, "name": row["name"], "series": row["series"], "role": row["role"]}})

@app.post("/api/auth/logout")
@require_auth
def logout():
    token = request.headers.get("Authorization", "").split(" ", 1)[1].strip()
    with db() as con:
        con.execute("DELETE FROM sessions WHERE token=?", (token,))
    return jsonify({"ok": True})

@app.get("/api/me")
@require_auth
def me():
    return jsonify({"ok": True, "user": request.user})

@app.post("/api/auth/request-reset")
def request_reset():
    data = request.get_json(force=True, silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    if not email or "@" not in email:
        return jsonify({"ok": False, "error": "invalid_email"}), 400

    with db() as con:
        user = con.execute("SELECT id FROM users WHERE email=?", (email,)).fetchone()
        if not user:
            return jsonify({"ok": True})
        token = new_id("reset")
        expires = (utc_now() + timedelta(minutes=30)).isoformat()
        con.execute("INSERT INTO password_resets(token, user_id, expires_at, created_at) VALUES (?,?,?,?)", (token, user["id"], expires, utc_now().isoformat()))
    return jsonify({"ok": True, "dev_token": token})

@app.post("/api/auth/reset")
def reset_password():
    data = request.get_json(force=True, silent=True) or {}
    token = (data.get("token") or "").strip()
    new_password = (data.get("new_password") or "")
    if len(new_password) < 6:
        return jsonify({"ok": False, "error": "weak_password"}), 400

    with db() as con:
        row = con.execute("SELECT token, user_id, expires_at, used_at FROM password_resets WHERE token=?", (token,)).fetchone()
        if not row:
            return jsonify({"ok": False, "error": "invalid_token"}), 400
        if row["used_at"]:
            return jsonify({"ok": False, "error": "token_used"}), 400
        if datetime.fromisoformat(row["expires_at"]).replace(tzinfo=timezone.utc) < utc_now():
            return jsonify({"ok": False, "error": "token_expired"}), 400

        con.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(new_password), row["user_id"]))
        con.execute("UPDATE password_resets SET used_at=? WHERE token=?", (utc_now().isoformat(), token))
    return jsonify({"ok": True})

@app.get("/api/admin/settings")
@require_auth
@require_admin
def admin_get_settings():
    with db() as con:
        return jsonify({"ok": True, "settings": get_settings(con)})

@app.put("/api/admin/settings")
@require_auth
@require_admin
def admin_put_settings():
    data = request.get_json(force=True, silent=True) or {}
    with db() as con:
        s = get_settings(con)
        s.update(data)  # merge superficial
        set_settings(con, s)
    return jsonify({"ok": True})

@app.get("/api/admin/attempts")
@require_auth
@require_admin
def admin_attempts():
    limit = int(request.args.get("limit") or 50)
    with db() as con:
        rows = con.execute(
            "SELECT a.*, u.email, u.name FROM saeb_attempts a JOIN users u ON u.id=a.user_id ORDER BY a.created_at DESC LIMIT ?",
            (limit,)
        ).fetchall()
        items = []
        for r in rows:
            d = _attempt_public(r)
            d["student"] = {"email": r["email"], "name": r["name"]}
            items.append(d)
        return jsonify({"ok": True, "items": items})

@app.post("/api/admin/questions/import")
@require_auth
@require_admin
def admin_import_questions():
    data = request.get_json(force=True, silent=True) or {}
    items = data.get("questions")
    if not isinstance(items, list):
        return jsonify({"ok": False, "error": "questions_missing"}), 400

    inserted = 0
    skipped = 0
    with db() as con:
        for q in items:
            try:
                year = str(q.get("year") or q.get("serie") or "").strip()
                subject = str(q.get("subject") or q.get("materia") or "lingua_portuguesa").strip()
                eixo = str(q.get("eixo") or q.get("axis") or "leitura").strip()
                bncc_code = q.get("bncc_code") or q.get("bncc") or q.get("habilidade") or None
                difficulty = str(q.get("difficulty") or q.get("dificuldade") or "medium").strip()
                prompt = str(q.get("prompt") or q.get("pergunta") or "").strip()
                options = q.get("options") or q.get("respostas") or []
                correct_index = int(q.get("correct_index") if q.get("correct_index") is not None else q.get("correta"))
                if not year or not prompt or not isinstance(options, list) or len(options) < 2:
                    raise ValueError("invalid")
                qid = q.get("id") or f"q_{year}_{secrets.token_hex(8)}"
                before = con.total_changes
                con.execute(
                    "INSERT OR IGNORE INTO questions(id, year, subject, eixo, bncc_code, difficulty, prompt, options_json, correct_index, created_at) "
                    "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                    (qid, year, subject, eixo, bncc_code, difficulty, prompt, json_dump(options), correct_index, utc_now().isoformat())
                )
                if con.total_changes > before:
                    inserted += 1
                else:
                    skipped += 1
            except Exception:
                skipped += 1

    return jsonify({"ok": True, "inserted": inserted, "skipped": skipped})

@app.get("/api/questions/count")
@require_auth
def questions_count():
    year = request.args.get("year") or (request.user.get("series") if getattr(request, "user", None) else None)
    with db() as con:
        if year:
            c = con.execute("SELECT COUNT(*) AS c FROM questions WHERE year=?", (year,)).fetchone()["c"]
        else:
            c = con.execute("SELECT COUNT(*) AS c FROM questions").fetchone()["c"]
    return jsonify({"ok": True, "count": c})

@app.post("/api/saeb/start")
@require_auth
def saeb_start():
    user = request.user
    if user.get("role") != "student":
        return jsonify({"ok": False, "error": "student_only"}), 403

    data = request.get_json(force=True, silent=True) or {}
    year = (data.get("year") or user.get("series") or "").strip()
    if not year:
        return jsonify({"ok": False, "error": "missing_year"}), 400

    with db() as con:
        s = get_settings(con)
        sa = s.get("saeb", {})

        # subjects: teacher can focus on one or more subjects
        subjects = data.get("subjects")
        if subjects is None:
            subjects = sa.get("subjects_default") or []
        if isinstance(subjects, str):
            subjects = [subjects]
        if not isinstance(subjects, list):
            subjects = []
        subjects = [str(x).strip() for x in subjects if str(x).strip()]
        allowed = sa.get("subjects_allowed") or []
        if allowed:
            subjects = [s for s in subjects if s in allowed]
        if not sa.get("enabled", True):
            return jsonify({"ok": False, "error": "saeb_disabled"}), 403

        time_limit_seconds = int(sa.get("time_limit_minutes", 90) * 60)
        blueprint = sa.get("eixos", {}) or {}
        total_questions = int(sa.get("total_questions", sum(int(v) for v in blueprint.values()) if blueprint else 24))

        if blueprint and sum(int(v) for v in blueprint.values()) != total_questions:
            total_questions = sum(int(v) for v in blueprint.values())

        qids = pick_questions(con, year, blueprint, bool(sa.get("shuffle_questions", True)), subjects)
        qids = qids[:total_questions]

        if not qids:
            return jsonify({"ok": False, "error": "no_questions_for_year"}), 404

        attempt_id = new_id("saeb")
        con.execute(
            "INSERT INTO saeb_attempts(id, user_id, created_at, started_at, time_limit_seconds, remaining_seconds, current_index, subjects_json, questions_json, answers_json, status) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (attempt_id, user["user_id"], utc_now().isoformat(), utc_now().isoformat(), time_limit_seconds, time_limit_seconds, 0, json_dump(subjects), json_dump(qids), "[]", "active")
        )
        first = fetch_question(con, qids[0])
        return jsonify({"ok": True, "attempt_id": attempt_id, "remaining_seconds": time_limit_seconds, "current_index": 0, "question": first})

@app.get("/api/saeb/session/<attempt_id>")
@require_auth
def saeb_session(attempt_id: str):
    user = request.user
    with db() as con:
        row = con.execute("SELECT * FROM saeb_attempts WHERE id=? AND user_id=?", (attempt_id, user["user_id"])).fetchone()
        if not row:
            return jsonify({"ok": False, "error": "not_found"}), 404

        if row["status"] != "active":
            return jsonify({"ok": True, "status": row["status"], "attempt": _attempt_public(row)})

        qids = json_load(row["questions_json"]) or []
        idx = int(row["current_index"])
        qid = qids[idx] if idx < len(qids) else None
        question = fetch_question(con, qid) if qid else None
        return jsonify({"ok": True, "status": row["status"], "attempt": _attempt_public(row), "question": question})

@app.post("/api/saeb/tick")
@require_auth
def saeb_tick():
    user = request.user
    data = request.get_json(force=True, silent=True) or {}
    attempt_id = (data.get("attempt_id") or "").strip()
    remaining = int(data.get("remaining_seconds", -1))
    if not attempt_id or remaining < 0:
        return jsonify({"ok": False, "error": "bad_request"}), 400

    with db() as con:
        row = con.execute("SELECT * FROM saeb_attempts WHERE id=? AND user_id=?", (attempt_id, user["user_id"])).fetchone()
        if not row:
            return jsonify({"ok": False, "error": "not_found"}), 404
        if row["status"] != "active":
            return jsonify({"ok": True, "status": row["status"]})

        status = "active"
        finished_at = None
        if remaining <= 0:
            status = "expired"
            finished_at = utc_now().isoformat()

        con.execute(
            "UPDATE saeb_attempts SET remaining_seconds=?, status=?, finished_at=COALESCE(?, finished_at) WHERE id=?",
            (max(0, remaining), status, finished_at, attempt_id)
        )
    return jsonify({"ok": True, "status": status})

@app.post("/api/saeb/answer")
@require_auth
def saeb_answer():
    user = request.user
    data = request.get_json(force=True, silent=True) or {}
    attempt_id = (data.get("attempt_id") or "").strip()
    question_id = (data.get("question_id") or "").strip()
    selected_index = data.get("selected_index")
    remaining_seconds = int(data.get("remaining_seconds", -1))

    if not attempt_id or not question_id or selected_index is None:
        return jsonify({"ok": False, "error": "bad_request"}), 400

    with db() as con:
        attempt = con.execute("SELECT * FROM saeb_attempts WHERE id=? AND user_id=?", (attempt_id, user["user_id"])).fetchone()
        if not attempt:
            return jsonify({"ok": False, "error": "not_found"}), 404
        if attempt["status"] != "active":
            return jsonify({"ok": False, "error": "not_active", "status": attempt["status"]}), 409

        qrow = con.execute("SELECT correct_index FROM questions WHERE id=?", (question_id,)).fetchone()
        correct = int(qrow["correct_index"]) if qrow else -999
        is_correct = int(selected_index) == correct

        answers = json_load(attempt["answers_json"]) or []
        answers.append({
            "question_id": question_id,
            "selected_index": int(selected_index),
            "is_correct": bool(is_correct),
            "answered_at": utc_now().isoformat()
        })

        qids = json_load(attempt["questions_json"]) or []
        idx = int(attempt["current_index"]) + 1
        status = "active"
        finished_at = None
        if idx >= len(qids):
            status = "finished"
            finished_at = utc_now().isoformat()
            idx = len(qids)

        rem = max(0, remaining_seconds) if remaining_seconds >= 0 else int(attempt["remaining_seconds"])

        con.execute(
            "UPDATE saeb_attempts SET answers_json=?, current_index=?, remaining_seconds=?, status=?, finished_at=COALESCE(?, finished_at) WHERE id=?",
            (json_dump(answers), idx, rem, status, finished_at, attempt_id)
        )

        next_q = fetch_question(con, qids[idx]) if status == "active" else None

    return jsonify({"ok": True, "status": status, "current_index": idx, "next_question": next_q})

@app.post("/api/saeb/abandon")
@require_auth
def saeb_abandon():
    user = request.user
    data = request.get_json(force=True, silent=True) or {}
    attempt_id = (data.get("attempt_id") or "").strip()
    remaining_seconds = int(data.get("remaining_seconds", -1))
    if not attempt_id or remaining_seconds < 0:
        return jsonify({"ok": False, "error": "bad_request"}), 400

    with db() as con:
        row = con.execute("SELECT * FROM saeb_attempts WHERE id=? AND user_id=?", (attempt_id, user["user_id"])).fetchone()
        if not row:
            return jsonify({"ok": False, "error": "not_found"}), 404
        if row["status"] != "active":
            return jsonify({"ok": True, "status": row["status"]})

        con.execute("UPDATE saeb_attempts SET remaining_seconds=? WHERE id=?", (max(0, remaining_seconds), attempt_id))
    return jsonify({"ok": True, "status": "active"})

@app.get("/api/saeb/result/<attempt_id>")
@require_auth
def saeb_result(attempt_id: str):
    user = request.user
    with db() as con:
        row = con.execute("SELECT * FROM saeb_attempts WHERE id=? AND user_id=?", (attempt_id, user["user_id"])).fetchone()
        if not row:
            return jsonify({"ok": False, "error": "not_found"}), 404
        answers = json_load(row["answers_json"]) or []
        total = len(json_load(row["questions_json"]) or [])
        correct = sum(1 for a in answers if a.get("is_correct"))
        return jsonify({"ok": True, "attempt": _attempt_public(row), "score": {"correct": correct, "total": total}})

def load_seed_questions_if_empty() -> None:
    seed_path = os.path.join(BASE_DIR, "seed_questions.json")
    if not os.path.exists(seed_path):
        return
    with db() as con:
        c = con.execute("SELECT COUNT(*) AS c FROM questions").fetchone()["c"]
        if c > 0:
            return
        with open(seed_path, "r", encoding="utf-8") as f:
            payload = json.load(f)
        data = payload.get("data") or []
        normalized: List[Dict[str, Any]] = []

        if isinstance(data, list) and data and isinstance(data[0], dict) and "questoes" in data[0]:
            for block in data:
                materia = (block.get("materia") or "lingua_portuguesa")
                serie = (block.get("serie") or "")
                for q in block.get("questoes", []):
                    normalized.append({
                        "year": serie,
                        "subject": "lingua_portuguesa" if str(materia).lower() in ("lp","lingua_portuguesa","portugues","língua portuguesa") else "artes",
                        "eixo": q.get("eixo") or "leitura",
                        "bncc_code": q.get("bncc_code") or q.get("bncc") or q.get("habilidade"),
                        "difficulty": q.get("dificuldade") or "medium",
                        "prompt": q.get("pergunta"),
                        "options": q.get("respostas"),
                        "correct_index": q.get("correta"),
                    })
        elif isinstance(data, list):
            normalized = [q for q in data if isinstance(q, dict)]

        if not normalized:
            return

        for q in normalized:
            try:
                year = str(q.get("year") or q.get("serie") or "").strip()
                prompt = str(q.get("prompt") or q.get("pergunta") or "").strip()
                options = q.get("options") or q.get("respostas") or []
                correct_index = int(q.get("correct_index") if q.get("correct_index") is not None else q.get("correta"))
                subject = str(q.get("subject") or q.get("materia") or "lingua_portuguesa").strip()
                eixo = str(q.get("eixo") or "leitura").strip()
                bncc_code = q.get("bncc_code") or q.get("bncc") or q.get("habilidade") or None
                difficulty = str(q.get("difficulty") or q.get("dificuldade") or "medium").strip()

                if not year or not prompt or not isinstance(options, list) or len(options) < 2:
                    continue
                qid = q.get("id") or f"q_{year}_{secrets.token_hex(8)}"
                con.execute(
                    "INSERT OR IGNORE INTO questions(id, year, subject, eixo, bncc_code, difficulty, prompt, options_json, correct_index, created_at) "
                    "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                    (qid, year, subject, eixo, bncc_code, difficulty, prompt, json_dump(options), correct_index, utc_now().isoformat())
                )
            except Exception:
                continue

if __name__ == "__main__":
    init_db()
    load_seed_questions_if_empty()
    app.run(host="127.0.0.1", port=5000, debug=True)
